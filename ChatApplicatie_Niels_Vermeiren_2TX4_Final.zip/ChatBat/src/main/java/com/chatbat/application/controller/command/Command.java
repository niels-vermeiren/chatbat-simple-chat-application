/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.chatbat.application.controller.command;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.Cookie;

/**
 *
 * @author niels
 */
public abstract class Command {

    protected HttpServletRequest request;

    private List<String> errors;
    private Map<String, String> requiredFields;

    public static final String ERRORS_ATTR = "errors";
    public static final String REQUIRED_FIELDS_ATTR = "requiredFields";

    public Command(HttpServletRequest request) {
        this();
        this.request = request;
    }

    private Command() {
    }

    public abstract void execute() throws CommandException;

    public void addRequiredField(String field, String message) {
        getRequiredFieldsInstance().put(field, message);
    }

    public void addErrorMessage(String errorMessage) {
        getErrorInstance().add(errorMessage);
    }

    public List<String> getErrors() {
        return getErrorInstance();
    }

    public Map<String, String> getRequiredFields() {
        return getRequiredFieldsInstance();
    }

    private Map<String, String> getRequiredFieldsInstance() {
        if (requiredFields == null) {
            requiredFields = (Map<String, String>) request.getAttribute(REQUIRED_FIELDS_ATTR);
            if (requiredFields == null) {
                requiredFields = new HashMap<>();
                request.setAttribute(REQUIRED_FIELDS_ATTR, requiredFields);
            }
        }
        return requiredFields;
    }

    private List<String> getErrorInstance() {
        if (errors == null) {
            errors = (List<String>) request.getAttribute(ERRORS_ATTR);
            if (errors == null) {
                errors = new ArrayList<>();
                request.setAttribute(ERRORS_ATTR, errors);
            }
        }
        return errors;
    }

    public Cookie getCookie(String cookieName) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals(cookieName)) {
                    return cookie;
                }
            }
        }
        return null;
    }

    /*
     protected ChatService service;
     protected EndpointManager manager;

     public abstract String execute(HttpServletRequest request, HttpServletResponse respons);

    
    
     protected Cookie getCookie(HttpServletRequest request, String cookieName) {
     Cookie cookieSearched = null;
     Cookie[] cookies = request.getCookies();
     if (cookies != null) {
     for (Cookie cookie : cookies) {
     if (cookie.getName().equals(cookieName)) {
     cookieSearched = cookie;
     return cookieSearched;
     }
     }
     }
     return null;
     }

     protected void remember(HttpServletRequest request, HttpServletResponse response, String email) {
     String remember = request.getParameter("remember");
     boolean rememberMe = Boolean.parseBoolean(remember);
     if (rememberMe) {
     Cookie cookie = new Cookie("email", email);
     response.addCookie(cookie);
     } else {
     Cookie cookie = getCookie(request, "email");
     if (cookie != null) {
     cookie.setMaxAge(0);
     }
     }
     }

     protected boolean isUserAuthenticated(HttpServletRequest request) {
     return request.getSession().getAttribute("user") != null;
     }
     */
}
