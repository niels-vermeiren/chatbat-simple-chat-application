/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.chatbat.application.controller.command;

/**
 *
 * @author niels
 */
public enum CommandEnum {
    TOLOGIN("toLogin", "com.chatbat.application.controller.command.ToLogin", false),
    LOGIN("login", "com.chatbat.application.controller.command.Login", false),
    REGISTER("register", "com.chatbat.application.controller.command.Register", false),
    TOREGISTER("toRegister", "com.chatbat.application.controller.command.ToRegister", false),
    LOGOUT("logout", "com.chatbat.application.controller.command.Logout", true),
    SENDMASSAGE("sendMessage", "com.chatbat.application.controller.command.sendMessage", true);
    private final String action;
    private final String command;
    private boolean authenticationNeeded;
    
    CommandEnum(String action, String command, boolean authenticationNeeded) {
        this.action = action;
        this.command = command;
        this.authenticationNeeded = authenticationNeeded;
    }
    
    public String getAction() {
        return this.action;
    }
    
    public String getCommand() {
        return this.command;
    }
    
    public boolean getAuthenticationNeeded() {
        return this.authenticationNeeded;
    }
        
}
