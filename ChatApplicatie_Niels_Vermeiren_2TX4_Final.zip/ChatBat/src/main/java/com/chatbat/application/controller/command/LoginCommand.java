/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.chatbat.application.controller.command;

import com.chatbat.domain.DomainException;
import javax.servlet.http.HttpServletRequest;
import com.chatbat.domain.User;
import com.chatbat.service.ChatService;

/**
 *
 * @author niels
 */
public class LoginCommand extends Command {

    public LoginCommand(HttpServletRequest request) {
        super(request);
    }

    @Override
    public void execute() throws CommandException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        if (email == null) {
            this.addErrorMessage("Email field cannot be empty");
            throw new MissingParameterException("email");
        } else {
            request.setAttribute("email", email);
        }

        if (password == null) {
            throw new MissingParameterException("password");
        }

        ChatService service = (ChatService) request.getServletContext().getAttribute("service");
        User user = service.getUserByMail(email);

        try {
            if (user == null || !user.isPasswordCorrect(password)) {
                if(!user.isPasswordCorrect(password)) {
                System.out.println("error");}
                
                this.addErrorMessage("Invalid user credentials");
                throw new CommandException("Invalid user credentials");
                
            } else {
                request.getSession(true).setAttribute("user", user);
                request.setAttribute("userId", user.getId());
            }
        } catch (DomainException ex) {
            throw new CommandException("Something went wrong");
        }

    }

}

/*
 public LoginCommand(ChatService service, EndpointManager epm) {
 this.service = service;
 this.manager = epm;
 }
    
 @Override
 public String execute(HttpServletRequest request, HttpServletResponse response) {
        
 String email = request.getParameter("email");
 String password = request.getParameter("password");
 User user = service.getUser(email);

 List<String> errorMessages = new ArrayList<>();
 String destination = "";
 if (user == null || !user.isPasswordCorrect(password)) {
 errorMessages.add("Invalid user credentials");
 request.setAttribute("errors", errorMessages);
 request.setAttribute("hasErrors", true);
 destination = "login.jsp";
 } else {
 remember(request, response, email);
 request.getSession().setAttribute("user", user);
 destination = "index.jsp";
 }
 response.setStatus(HttpServletResponse.SC_FOUND); 
 response.setHeader("Location", "/ChatBat/");
 return destination;
 }*/
