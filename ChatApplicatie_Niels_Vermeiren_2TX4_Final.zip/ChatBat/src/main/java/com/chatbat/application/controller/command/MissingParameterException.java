/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.chatbat.application.controller.command;

/**
 *
 * @author niels
 */
public class MissingParameterException extends CommandException {
    
    /* Parameter name stored, for convenience, as a separate field,
     * independent of the message.
     */
    private String parameterName = "";

    public MissingParameterException(String parameterName) {
        super();
        this.parameterName = parameterName;
    }

    public MissingParameterException(String parameterName, String message) {
        super(message);
        this.parameterName = parameterName;
    }

    public MissingParameterException(String parameterName, Throwable t) {
        super(t);
        this.parameterName = parameterName;
    }

    public MissingParameterException(String parameterName, String message, Throwable t) {
        super(message, t);
        this.parameterName = parameterName;
    }

    public String getParameterName() {
        return parameterName;
    }

    public void setParameterName(String parameterName) {
        this.parameterName = parameterName;
    }

}
