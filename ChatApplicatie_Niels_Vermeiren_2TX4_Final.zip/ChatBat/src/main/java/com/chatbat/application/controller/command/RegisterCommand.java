/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.chatbat.application.controller.command;

import com.chatbat.domain.DomainException;
import com.chatbat.domain.User;
import com.chatbat.service.ChatService;
import com.chatbat.service.ServiceException;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author niels
 */
public class RegisterCommand extends Command {

    private final static String ALLOWED_CHARS = "[A-Za-z0-9_\\-]";

    public RegisterCommand(HttpServletRequest request) {
        super(request);
    }

    @Override
    public void execute() throws CommandException {

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        if (name == null) {
            getRequiredFields().put("name", "Name can't be empty");
            addErrorMessage("Name can't be empty");
        } else {
            request.setAttribute("name", name);
            if (name.length() < 3 || name.length() > 20) {
                
                addErrorMessage("Names must contain 3 to 20 characters");
            } else if (name.replaceAll(ALLOWED_CHARS, "").length() > 0) {
                
                addErrorMessage("Name contains an invalid character");
            }
            /*else {
             if (service.isUsernameTaken(name)) {
             getRequiredFields().put("name", "This name is already taken");
             }
             }*/
        }

        //Email
        if (email == null) {
            addErrorMessage("Email can't be empty");
            
        }

        //Password
        if (password == null) {
            addErrorMessage("Password can't be empty");
            
        } else if (password.length() < 8) {
            addErrorMessage("Password must be at least 8 characters");
            
        }

        if (getErrors().size() > 0) {
            throw new CommandException("");
        }

        ChatService service = (ChatService) request.getServletContext().getAttribute("service");

        User user = null;
        try {
            user = new User(name, email, password);
            service.addUser(user);
        } catch (DomainException | ServiceException ex) {
            throw new CommandException();
        }

    }

}
