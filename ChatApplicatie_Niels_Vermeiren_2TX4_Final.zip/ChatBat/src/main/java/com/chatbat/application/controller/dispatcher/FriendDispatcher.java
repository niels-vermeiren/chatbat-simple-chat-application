/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.chatbat.application.controller.dispatcher;

import java.io.IOException;
import javax.servlet.ServletException;

/**
 *
 * @author niels
 */
@DispatcherAnnotation(dispatcher = "friends")
public class FriendDispatcher extends Dispatcher {

    @Override
    public void execute() throws ServletException, IOException {
        
        
        
        response.setContentType("application/json");
        
        response.getWriter().write("{\"data\":\"friends\"}");
    }
    
}
