/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.chatbat.database.memory;

import com.chatbat.database.Mapper;
import com.chatbat.database.MapperException;
import com.chatbat.domain.DomainException;
import com.chatbat.domain.User;
import com.chatbat.domain.UserState;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author niels
 */
public class MemoryUserMapper implements Mapper<User> {

    private final Map<Long, User> users;
    private static long maxId;

    public MemoryUserMapper() {
        users = new HashMap<>();
        
        User niels = null, simon = null, mark = null;
        try {
            niels = new User("Niels", "vermeiren_niels@hotmail.com", "secret");
            simon = new User("Simon", "simoncek@hotmail.com", "secret");
            mark = new User("Mark", "markthoelen@boerinnekes.be", "secret");
        } catch (DomainException ex) {
            Logger.getLogger(MemoryUserMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
        niels.addFriend(simon);
        niels.setState(UserState.OFFLINE);
        niels.addFriend(mark);
        mark.setState(UserState.AWAY);
        mark.addFriend(niels);
        simon.addFriend(niels);
        simon.setState(UserState.OFFLINE);
        try {
            store(niels);
            store(simon);
            store(mark);
        } catch (MapperException ex) {
            Logger.getLogger(MemoryUserMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public long store(User user) throws MapperException {
        //TODO: exception als user al bestaat
        long id = maxId++;
   
        
        user.setId(id);
        users.put(id, user);
        return id;
    }

    @Override
    public void update(User user) throws MapperException {
        User toUpdate = users.get(user.getId());
        if (toUpdate == null) {
            throw new MapperException("User with id '" + user.getId() + "' not found");
        }
        users.put(user.getId(), user);
    }

    @Override
    public void delete(long id) throws MapperException {
        User toDelete = users.get(id);
        if (toDelete == null) {
            throw new MapperException("User with id '" + id + "' not found");
        }
        users.remove(id);
    }

    @Override
    public User find(long id) throws MapperException {
        
        User user = users.get(id);
        if (user == null) {
            throw new MapperException("User with id '" + id + "' not found");
        }
        return user;
    }
    
    public User findByEmail(String email) {
        for(User u: users.values()) {
            if(u.getEmail().equals(email)) {
                return u;
            }
        }
        return null;
    }

    @Override
    public Collection<User> findAll() {
        return users.values();
    }

    @Override
    public void clear() throws MapperException {
        users.clear();
    }

    @Override
    public User findByFieldName(String field, String value) throws MapperException {
        User u = null;
        switch(field) {
            case "email": 
                u = findByEmail(value);
                break;
            default:
                break;
        }
        return u;
    }

}
