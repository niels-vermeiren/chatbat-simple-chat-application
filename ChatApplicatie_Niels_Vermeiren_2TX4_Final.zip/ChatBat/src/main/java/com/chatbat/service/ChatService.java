/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.chatbat.service;

import com.chatbat.application.controller.command.CommandEnum;
import com.chatbat.database.MapperException;
import com.chatbat.database.MapperLocator;
import com.chatbat.database.memory.MemoryMapperLocator;
import com.chatbat.domain.Message;
import com.chatbat.domain.User;
import com.chatbat.domain.UserState;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author niels
 */
public class ChatService {

     public static ChatService getInstance() {
        return ChatServiceHolder.getInstance();
    }

    private final static class ChatServiceHolder {

        private static final ChatService INSTANCE = new ChatService();

        private static ChatService getInstance() {
            return INSTANCE;
        }
    }
    
    private ChatService() {
        MapperLocator.loadLocator(new MemoryMapperLocator());
    }

    public void addUser(User user) throws ServiceException {
        try {
            MapperLocator.userMapper().store(user);
        } catch (MapperException ex) {
            throw new ServiceException(ex);
        }
    }

    public void updateUser(User user) throws ServiceException {
        try {
            MapperLocator.userMapper().update(user);
        } catch (MapperException ex) {
            throw new ServiceException(ex);
        }
    }

    public void deleteUser(long id) throws ServiceException {
        try {
            MapperLocator.userMapper().delete(id);
        } catch (MapperException ex) {
            throw new ServiceException(ex);
        }
    }

    public User getUserByMail(String email) {
        User u = null; 
        try {
             u = MapperLocator.userMapper().findByFieldName("email", email);
         } catch (MapperException ex) {
             Logger.getLogger(ChatService.class.getName()).log(Level.SEVERE, null, ex);
         }
        return u;
    }
    
    public User getUser(long id) {
        User u = null;
        try {
            u = MapperLocator.userMapper().find(id);
        } catch(MapperException ex) {
            Logger.getLogger(ChatService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return u;
    }

    public long sendMessage(String content, long from, long to) throws ServiceException {
        Message message = new Message();
        message.setContent(content);
        message.setFromUser(from);
        message.setToUser(to);
        try {
            return MapperLocator.messageMapper().store(message);
        } catch (MapperException ex) {
            throw new ServiceException(ex);
        }
    }

    public Message getMessage(long id) throws ServiceException {
        try {
            return MapperLocator.messageMapper().find(id);
        } catch (MapperException ex) {
            throw new ServiceException(ex);
        }
    }

    public void close() throws ServiceException {
        MapperException localException = null;
        try {
            MapperLocator.userMapper().clear();
        } catch (MapperException ex) {
            localException=ex;
        }
        try {
            MapperLocator.messageMapper().clear();
        } catch (MapperException ex) {
            localException=ex;
        }
        if(localException != null) {
            throw new ServiceException(localException);
        }
    }
    
    public boolean isAuthenticationNeeded(String action) {
        CommandEnum[] commands = CommandEnum.values();
        CommandEnum result = null;
        for(int i=0; i!= commands.length; i++) {
            if(commands[i].getAction().equals(action)) {
                result = commands[i];
            }
        }
        return result.getAuthenticationNeeded();
    }
    
    public void changeUserState(User u, UserState state) {
        u.setState(state);
    }
    
    public String getUserState(User u) {
        return u.getState();
    }
  
}
