var ws;
var userId;
//WEBSOCKET
function openSocket() {
    //TODO: Fix url
    var wsUri = "ws://" + document.location.host + "/ChatBat/wsConnect";
    ws = new WebSocket(wsUri);

    ws.onerror = function (msg) {
    };

    ws.onopen = function (msg) {
        console.info("Socket is now open.");
        changeStatus("Online");
        $("#changeStatus").val("Online");
        getFriends();
    };

    ws.onmessage = function (msg) {
        var json = jQuery.parseJSON(msg.data);
        console.log(json.action);
        switch(json.action) {
            case "getFriends":
                populateFriends(json);
                break;
            case "statusChange":
                getFriends();
                break;
        }
    };

    ws.onclose = function () {
        console.info("Socket is now closed.");
        changeStatus("Offline");
    };

}
//EVENT LISTENERS
$(document).ready(function () {
    //User clicks logout
    $("#logout").on('click', function () {
        console.log("logging out");
        ws.send(JSON.stringify({
            "action": "changeStatus",
            "userId": userId,
            "status": "Offline"
        }));
    });

    //User changes status manually
    $("#changeStatus").on('change', function () {
        changeStatus($(this).val());
    });
    
    //Search friends
    $("#filterFriends").keyup(function() {
        getFriends();
    });
});

//FUNCTIONS
//Connect
function connect(id) {
    userId = id;
    openSocket();
}

//Change status user
function changeStatus(status) {
    ws.send(JSON.stringify({
        "action": "changeStatus",
        "userId": userId,
        "status": status
    }));
}

//Get all friends
//Niet met polling geïmplementeerd aangezien ik al een connectie via websockets heb openstaan (heb de code wel nog indien u dit wil zien)
function getFriends() {
    var friendsFilter = $("#filterFriends");
    ws.send(JSON.stringify({
        "action": "getFriends",
        "userId": userId,
        "filterFriends": friendsFilter.val()
    }));
}

//Populate all friends
function populateFriends(json) {
    var friends = $("#friends");
    friends.html("");
   
    $.each(json.friends, function(key, value){
        var span = $("<span></span>", {
            "class": "glyphicon glyphicon-chevron-right "+value.state.toLowerCase()
        }); 
        var wrapper = $("<a></a>", {
            href: "#",
            "class": "list-group-item",
            "data-id": value.id
        });
        wrapper.append(span);
        wrapper.append(" " + value.name);
        friends.append(wrapper);
    });
}

